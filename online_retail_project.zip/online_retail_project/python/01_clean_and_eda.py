"""
Online Retail Analytics Project  |  Step 1 of 4  |  PYTHON
=========================================================
Cleaning -> Feature engineering -> EDA -> RFM segmentation -> Cohort retention

Run from the project root:
    python python/01_clean_and_eda.py

Inputs : data/raw/Online_Retail.csv
Outputs: data/clean/online_retail_clean.csv      (feeds PostgreSQL + Power BI)
         data/clean/rfm_customers.csv            (customer segments)
         outputs/*.csv                           (summary tables for Excel)
         outputs/charts/*.png                    (EDA charts for the report)
         outputs/data_quality_log.csv            (rows removed at each step)
"""

from pathlib import Path
import warnings

import matplotlib
matplotlib.use("Agg")  # no GUI needed
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# ----------------------------------------------------------------------------
# 0. PATHS & SETTINGS
# ----------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "Online_Retail.csv"
CLEAN_DIR = ROOT / "data" / "clean"
OUT = ROOT / "outputs"
CHARTS = OUT / "charts"
for p in (CLEAN_DIR, OUT, CHARTS):
    p.mkdir(parents=True, exist_ok=True)

warnings.filterwarnings("ignore")  # hide seaborn palette deprecation notices
sns.set_theme(style="whitegrid", context="talk", palette="viridis")
plt.rcParams.update({"figure.figsize": (12, 6), "axes.titleweight": "bold"})

# Stock codes that are NOT physical products (postage, fees, manual adjustments...)
NON_PRODUCT_CODES = {
    "POST", "DOT", "M", "m", "C2", "D", "S", "B", "BANK CHARGES",
    "AMAZONFEE", "CRUK", "PADS", "ADJUST", "ADJUST2", "CARRIAGE",
}

log = []  # data-quality log


def track(step: str, before: int, after: int) -> None:
    log.append({"step": step, "rows_before": before, "rows_after": after,
                "rows_removed": before - after})
    print(f"[{step:<42}] {before:>8,} -> {after:>8,}  (-{before - after:,})")


# ----------------------------------------------------------------------------
# 1. LOAD
# ----------------------------------------------------------------------------
print("=" * 78, "\n1. LOADING DATA\n" + "=" * 78)
df = pd.read_csv(RAW, encoding="latin1", dtype={"InvoiceNo": str, "StockCode": str})
print(f"Shape: {df.shape}")
print(df.dtypes, "\n")
print("Missing values:\n", df.isna().sum(), "\n")

# ----------------------------------------------------------------------------
# 2. CLEANING
# ----------------------------------------------------------------------------
print("=" * 78, "\n2. CLEANING\n" + "=" * 78)
n = len(df)

# 2.1 exact duplicate rows
df = df.drop_duplicates()
track("Drop exact duplicate rows", n, len(df)); n = len(df)

# 2.2 parse dates (source format is dd-mm-yyyy HH:MM)
df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], format="%d-%m-%Y %H:%M")

# 2.3 tidy text columns
df["Description"] = df["Description"].str.strip().str.upper()
df["Country"] = df["Country"].str.strip()
df["StockCode"] = df["StockCode"].str.strip().str.upper()

# 2.4 flag cancellations (invoice numbers starting with 'C')
df["IsReturn"] = df["InvoiceNo"].str.upper().str.startswith("C")

# 2.5 remove non-product lines (postage, bank charges, manual, gift vouchers ...)
mask_nonprod = df["StockCode"].isin({c.upper() for c in NON_PRODUCT_CODES}) | \
               df["StockCode"].str.startswith("GIFT_")
df = df[~mask_nonprod]
track("Remove non-product stock codes", n, len(df)); n = len(df)

# 2.6 remove zero / negative prices (free items & accounting adjustments)
df = df[df["UnitPrice"] > 0]
track("Remove UnitPrice <= 0", n, len(df)); n = len(df)

# 2.7 non-return rows must have positive quantity
#     (negative qty on a normal invoice = damaged / lost stock adjustments)
df = df[df["IsReturn"] | (df["Quantity"] > 0)]
track("Remove negative qty on non-return invoices", n, len(df)); n = len(df)

# 2.8 returns must have negative quantity
df = df[~df["IsReturn"] | (df["Quantity"] < 0)]
track("Remove returns with positive qty", n, len(df)); n = len(df)

# 2.9 fill missing descriptions from the most common description of the same code
desc_map = (df.dropna(subset=["Description"])
              .groupby("StockCode")["Description"]
              .agg(lambda s: s.value_counts().index[0]))
df["Description"] = df["Description"].fillna(df["StockCode"].map(desc_map))
df = df.dropna(subset=["Description"])
track("Drop rows with no description at all", n, len(df)); n = len(df)

# 2.10 one canonical description per StockCode (keeps the dimension table clean)
df["Description"] = df["StockCode"].map(desc_map).fillna(df["Description"])

# 2.11 CustomerID: ~25% missing (guest checkouts). Keep rows for revenue analysis,
#      flag them, and exclude them only from customer-level analysis (RFM/cohort).
df["HasCustomer"] = df["CustomerID"].notna()
df["CustomerID"] = df["CustomerID"].astype("Int64")

# 2.12 outliers: keep, but flag extreme order lines (e.g. qty 80,995 / 74,215)
q99 = df.loc[~df["IsReturn"], "Quantity"].quantile(0.999)
df["IsOutlierQty"] = df["Quantity"].abs() > q99
print(f"Quantity 99.9th percentile = {q99:.0f}; flagged {df['IsOutlierQty'].sum():,} lines")

# ----------------------------------------------------------------------------
# 3. FEATURE ENGINEERING
# ----------------------------------------------------------------------------
print("\n" + "=" * 78, "\n3. FEATURE ENGINEERING\n" + "=" * 78)
df["Revenue"] = (df["Quantity"] * df["UnitPrice"]).round(2)  # negative for returns
df["Date"] = df["InvoiceDate"].dt.date
df["Year"] = df["InvoiceDate"].dt.year
df["Month"] = df["InvoiceDate"].dt.month
df["MonthName"] = df["InvoiceDate"].dt.strftime("%b")
df["YearMonth"] = df["InvoiceDate"].dt.to_period("M").astype(str)
df["Quarter"] = "Q" + df["InvoiceDate"].dt.quarter.astype(str)
df["DayOfWeek"] = df["InvoiceDate"].dt.day_name()
df["Hour"] = df["InvoiceDate"].dt.hour

sales = df[~df["IsReturn"]].copy()
returns = df[df["IsReturn"]].copy()

# ----------------------------------------------------------------------------
# 4. EXPORT CLEAN DATA  (ISO timestamps so PostgreSQL's COPY can read them)
# ----------------------------------------------------------------------------
export_cols = ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
               "UnitPrice", "CustomerID", "Country", "Revenue", "IsReturn",
               "HasCustomer", "IsOutlierQty"]
out = df[export_cols].copy()
out["InvoiceDate"] = out["InvoiceDate"].dt.strftime("%Y-%m-%d %H:%M:%S")
out.to_csv(CLEAN_DIR / "online_retail_clean.csv", index=False)
pd.DataFrame(log).to_csv(OUT / "data_quality_log.csv", index=False)
print(f"\nSaved clean file: {len(out):,} rows -> data/clean/online_retail_clean.csv")

# ----------------------------------------------------------------------------
# 5. KPIs
# ----------------------------------------------------------------------------
print("\n" + "=" * 78, "\n5. HEADLINE KPIs\n" + "=" * 78)
gross = sales["Revenue"].sum()
ret = -returns["Revenue"].sum()
kpis = {
    "Gross Revenue": gross,
    "Returns Value": ret,
    "Net Revenue": gross - ret,
    "Return Rate %": ret / gross * 100,
    "Orders": sales["InvoiceNo"].nunique(),
    "Customers (identified)": sales["CustomerID"].nunique(),
    "Products Sold": sales["StockCode"].nunique(),
    "Countries": sales["Country"].nunique(),
    "Avg Order Value": gross / sales["InvoiceNo"].nunique(),
    "Units Sold": sales["Quantity"].sum(),
    "Guest Checkout Revenue %": sales.loc[~sales["HasCustomer"], "Revenue"].sum() / gross * 100,
}
kpi_df = pd.DataFrame(kpis.items(), columns=["KPI", "Value"])
kpi_df["Value"] = kpi_df["Value"].round(2)
kpi_df.to_csv(OUT / "kpi_summary.csv", index=False)
print(kpi_df.to_string(index=False))

# ----------------------------------------------------------------------------
# 6. EXPLORATORY DATA ANALYSIS
# ----------------------------------------------------------------------------
print("\n" + "=" * 78, "\n6. EDA\n" + "=" * 78)

# 6.1 Monthly trend
monthly = (sales.groupby("YearMonth")
           .agg(GrossRevenue=("Revenue", "sum"), Orders=("InvoiceNo", "nunique"),
                Customers=("CustomerID", "nunique"), Units=("Quantity", "sum"))
           .join((-returns.groupby("YearMonth")["Revenue"].sum()).rename("Returns"))
           .fillna(0).reset_index())
monthly["NetRevenue"] = monthly["GrossRevenue"] - monthly["Returns"]
monthly["MoM_Growth_%"] = monthly["NetRevenue"].pct_change() * 100
monthly.round(2).to_csv(OUT / "monthly_summary.csv", index=False)

fig, ax = plt.subplots()
ax.bar(monthly["YearMonth"], monthly["NetRevenue"], color=sns.color_palette("viridis", 1)[0])
ax.plot(monthly["YearMonth"], monthly["Orders"] * monthly["NetRevenue"].max() / monthly["Orders"].max(),
        color="tomato", marker="o", label="Orders (scaled)")
ax.set(title="Monthly Net Revenue & Order Volume", xlabel="", ylabel="Net revenue (GBP)")
ax.tick_params(axis="x", rotation=45); ax.legend()
plt.tight_layout(); plt.savefig(CHARTS / "01_monthly_revenue.png", dpi=150); plt.close()

# 6.2 Top countries
country = (sales.groupby("Country")
           .agg(Revenue=("Revenue", "sum"), Orders=("InvoiceNo", "nunique"),
                Customers=("CustomerID", "nunique")).sort_values("Revenue", ascending=False))
country["Share_%"] = country["Revenue"] / country["Revenue"].sum() * 100
country.round(2).reset_index().to_csv(OUT / "country_summary.csv", index=False)

top_nonuk = country.drop("United Kingdom", errors="ignore").head(10)
fig, ax = plt.subplots()
sns.barplot(x=top_nonuk["Revenue"], y=top_nonuk.index, ax=ax, palette="mako")
ax.set(title="Top 10 Countries by Revenue (excl. United Kingdom)", xlabel="Revenue (GBP)", ylabel="")
plt.tight_layout(); plt.savefig(CHARTS / "02_top_countries.png", dpi=150); plt.close()

# 6.3 Top products
product = (sales.groupby(["StockCode", "Description"])
           .agg(Revenue=("Revenue", "sum"), Units=("Quantity", "sum"),
                Orders=("InvoiceNo", "nunique")).reset_index()
           .sort_values("Revenue", ascending=False))
product.round(2).head(50).to_csv(OUT / "top_products.csv", index=False)

fig, ax = plt.subplots(figsize=(13, 7))
t10 = product.head(10)
sns.barplot(x=t10["Revenue"], y=t10["Description"].str.title().str[:35], ax=ax, palette="rocket")
ax.set(title="Top 10 Products by Revenue", xlabel="Revenue (GBP)", ylabel="")
plt.tight_layout(); plt.savefig(CHARTS / "03_top_products.png", dpi=150); plt.close()

# 6.4 Pareto (80/20) of products
p = product["Revenue"].cumsum() / product["Revenue"].sum() * 100
n80 = int((p < 80).sum() + 1)
print(f"Pareto: {n80:,} products ({n80 / len(product) * 100:.1f}% of catalogue) = 80% of revenue")

# 6.5 Day-of-week and hour-of-day patterns
dow_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
dow = sales.groupby("DayOfWeek")["Revenue"].sum().reindex(dow_order).fillna(0)
hour = sales.groupby("Hour")["Revenue"].sum()
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
sns.barplot(x=dow.index, y=dow.values, ax=axes[0], palette="crest")
axes[0].set(title="Revenue by Day of Week", xlabel="", ylabel="GBP"); axes[0].tick_params(axis="x", rotation=45)
sns.lineplot(x=hour.index, y=hour.values, ax=axes[1], marker="o", color="tomato")
axes[1].set(title="Revenue by Hour of Day", xlabel="Hour", ylabel="GBP")
plt.tight_layout(); plt.savefig(CHARTS / "04_day_hour_pattern.png", dpi=150); plt.close()

# 6.6 Distributions (log scale because of heavy right skew)
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for ax, col, title in zip(axes, ["Quantity", "UnitPrice", "Revenue"],
                          ["Quantity per line", "Unit price", "Revenue per line"]):
    sns.histplot(np.log10(sales[col].clip(lower=0.01)), bins=50, ax=ax, color="steelblue")
    ax.set(title=f"{title} (log10)", xlabel=f"log10({col})")
plt.tight_layout(); plt.savefig(CHARTS / "05_distributions.png", dpi=150); plt.close()

# 6.7 Basic stats (dispersion, skew) - useful for the report
stats = sales[["Quantity", "UnitPrice", "Revenue"]].describe().T
stats["skew"] = sales[["Quantity", "UnitPrice", "Revenue"]].skew()
stats["IQR"] = stats["75%"] - stats["25%"]
stats.round(2).to_csv(OUT / "descriptive_stats.csv")
print("\nDescriptive stats:\n", stats.round(2))

# 6.8 Returns analysis
ret_prod = (returns.groupby("Description")["Revenue"].sum().mul(-1)
            .sort_values(ascending=False).head(10))
print("\nTop returned products (value):\n", ret_prod.round(0))
ret_prod.round(2).reset_index().rename(columns={"Revenue": "ReturnValue"}) \
        .to_csv(OUT / "top_returned_products.csv", index=False)

# ----------------------------------------------------------------------------
# 7. RFM CUSTOMER SEGMENTATION
# ----------------------------------------------------------------------------
print("\n" + "=" * 78, "\n7. RFM SEGMENTATION\n" + "=" * 78)
cust = sales[sales["HasCustomer"]]
snapshot = cust["InvoiceDate"].max() + pd.Timedelta(days=1)
rfm = (cust.groupby("CustomerID")
       .agg(Recency=("InvoiceDate", lambda s: (snapshot - s.max()).days),
            Frequency=("InvoiceNo", "nunique"),
            Monetary=("Revenue", "sum"),
            Country=("Country", "first"))
       .reset_index())

# quintile scores (rank first so duplicates in Frequency don't break qcut)
rfm["R"] = pd.qcut(rfm["Recency"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F"] = pd.qcut(rfm["Frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M"] = pd.qcut(rfm["Monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["RFM_Score"] = rfm["R"].astype(str) + rfm["F"].astype(str) + rfm["M"].astype(str)


def segment(r):
    if r.R >= 4 and r.F >= 4:           return "Champions"
    if r.R >= 3 and r.F >= 4:           return "Loyal Customers"
    if r.R >= 4 and r.F <= 2:           return "New / Promising"
    if r.R >= 3 and r.F >= 3:           return "Potential Loyalists"
    if r.R <= 2 and r.F >= 4:           return "Can't Lose Them"
    if r.R <= 2 and r.F >= 3:           return "At Risk"
    if r.R <= 2 and r.F <= 2 and r.M <= 2: return "Lost"
    return "Needs Attention"


rfm["Segment"] = rfm.apply(segment, axis=1)
rfm.round(2).to_csv(CLEAN_DIR / "rfm_customers.csv", index=False)

seg = (rfm.groupby("Segment")
       .agg(Customers=("CustomerID", "count"), AvgRecency=("Recency", "mean"),
            AvgFrequency=("Frequency", "mean"), AvgMonetary=("Monetary", "mean"),
            Revenue=("Monetary", "sum"))
       .sort_values("Revenue", ascending=False))
seg["Revenue_Share_%"] = seg["Revenue"] / seg["Revenue"].sum() * 100
seg.round(2).reset_index().to_csv(OUT / "rfm_segment_summary.csv", index=False)
print(seg.round(1))

fig, ax = plt.subplots()
sns.barplot(x=seg.index, y=seg["Revenue"], ax=ax, palette="viridis")
ax.set(title="Revenue by RFM Segment", xlabel="", ylabel="GBP"); ax.tick_params(axis="x", rotation=30)
plt.tight_layout(); plt.savefig(CHARTS / "06_rfm_segments.png", dpi=150); plt.close()

# ----------------------------------------------------------------------------
# 8. COHORT RETENTION (month of first purchase)
# ----------------------------------------------------------------------------
print("\n" + "=" * 78, "\n8. COHORT RETENTION\n" + "=" * 78)
c = cust[["CustomerID", "InvoiceDate"]].copy()
c["OrderMonth"] = c["InvoiceDate"].dt.to_period("M")
c["CohortMonth"] = c.groupby("CustomerID")["OrderMonth"].transform("min")
c["CohortIndex"] = (c["OrderMonth"] - c["CohortMonth"]).apply(lambda x: x.n)
cohort = (c.groupby(["CohortMonth", "CohortIndex"])["CustomerID"].nunique()
          .unstack(fill_value=0))
retention = cohort.divide(cohort[0], axis=0) * 100
retention.round(1).to_csv(OUT / "cohort_retention.csv")

fig, ax = plt.subplots(figsize=(15, 8))
sns.heatmap(retention, annot=True, fmt=".0f", cmap="YlGnBu", ax=ax,
            cbar_kws={"label": "Retention %"})
ax.set(title="Customer Retention by Monthly Cohort (%)", xlabel="Months since first purchase", ylabel="Cohort")
plt.tight_layout(); plt.savefig(CHARTS / "07_cohort_retention.png", dpi=150); plt.close()

# ----------------------------------------------------------------------------
# 9. CORRELATION
# ----------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7, 6))
sns.heatmap(sales[["Quantity", "UnitPrice", "Revenue"]].corr(), annot=True, cmap="coolwarm", ax=ax)
ax.set_title("Correlation Matrix")
plt.tight_layout(); plt.savefig(CHARTS / "08_correlation.png", dpi=150); plt.close()

print("\nDone. Charts in outputs/charts/, tables in outputs/, clean data in data/clean/")
