"""
Online Retail Analytics Project  |  Step 2b  |  PYTHON -> POSTGRESQL
=====================================================================
Creates the schema, bulk-loads the clean CSV files with COPY, builds the star
schema, and creates the Power BI views - by running the .sql files in order.

1. Install:   pip install psycopg2-binary
2. Create the database once:   CREATE DATABASE retail_db;
3. Edit DB_CONFIG below (or set environment variables PGHOST, PGPORT, ...)
4. Run:       python python/02_load_to_postgres.py
"""

import os
from pathlib import Path

import psycopg2

ROOT = Path(__file__).resolve().parents[1]

DB_CONFIG = {
    "host":     os.getenv("PGHOST", "localhost"),
    "port":     os.getenv("PGPORT", "5432"),
    "dbname":   os.getenv("PGDATABASE", "retail_db"),
    "user":     os.getenv("PGUSER", "postgres"),
    "password": os.getenv("PGPASSWORD", "your_password"),   # <-- change me
}


def run_sql_file(cur, name: str) -> None:
    print(f"Running {name} ...")
    cur.execute((ROOT / "sql" / name).read_text(encoding="utf-8"))


def copy_csv(cur, table: str, csv_path: Path, columns: str) -> None:
    print(f"Loading {csv_path.name} -> {table} ...")
    with open(csv_path, "r", encoding="utf-8") as f:
        cur.copy_expert(
            f"COPY {table} ({columns}) FROM STDIN WITH (FORMAT csv, HEADER true, NULL '')", f)
    cur.execute(f"SELECT COUNT(*) FROM {table}")
    print(f"   {cur.fetchone()[0]:,} rows loaded")


def main() -> None:
    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = False
    try:
        with conn.cursor() as cur:
            run_sql_file(cur, "01_create_schema.sql")
            cur.execute("SET search_path TO retail")

            copy_csv(cur, "stg_sales", ROOT / "data/clean/online_retail_clean.csv",
                     "invoice_no, stock_code, description, quantity, invoice_date, unit_price, "
                     "customer_id, country, revenue, is_return, has_customer, is_outlier_qty")
            copy_csv(cur, "rfm_customers", ROOT / "data/clean/rfm_customers.csv",
                     "customer_id, recency, frequency, monetary, country, "
                     "r_score, f_score, m_score, rfm_score, segment")

            run_sql_file(cur, "02_build_star_schema.sql")
            run_sql_file(cur, "04_views_for_powerbi.sql")
        conn.commit()
        print("\nPostgreSQL warehouse built successfully (schema: retail).")
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()
