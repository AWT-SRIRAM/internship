# Online Retail Analytics – End-to-End Project
**Tools:** Python · PostgreSQL · Excel · Power BI  |  **Dataset:** UCI Online Retail (541,909 rows, 01 Dec 2010 – 09 Dec 2011, GBP)

## Business questions
1. How is revenue trending and when is the peak season?
2. Which countries and products drive revenue?
3. Who are the best customers and which are at risk of churning?
4. How big is the returns problem and which products cause it?

## Pipeline
```
Online_Retail.csv ─► [1 Python] clean, EDA, RFM, cohorts ─► data/clean/*.csv, outputs/*.csv, charts
                                   │
                                   ├─► [2 PostgreSQL] staging → star schema → analysis SQL → views
                                   ├─► [3 Excel]      KPI workbook (formulas, charts, pivots)
                                   └─► [4 Power BI]   star-schema model, DAX, 4-page dashboard
```

## Folder structure
```
python/01_clean_and_eda.py         cleaning, features, EDA charts, RFM, cohort retention
python/02_load_to_postgres.py      runs the SQL files + bulk-loads CSVs with COPY
sql/01_create_schema.sql           staging + dim_date/product/country/customer + fact_sales
sql/02_build_star_schema.sql       populate dimensions and fact, indexes, reconciliation check
sql/03_analysis_queries.sql        12 queries: KPIs, LAG, RANK, ROW_NUMBER, NTILE, cohort, basket
sql/04_views_for_powerbi.sql       vw_sales_detail, vw_monthly_kpi
sql/load_with_psql.sql             alternative loader using psql \copy
excel/build_excel_workbook.py      builds Online_Retail_Analysis.xlsx (≈10k live formulas)
excel/EXCEL_GUIDE.md               Power Query + pivot-table steps done by hand
powerbi/01_power_query_postgres.m  Power Query (M) connection scripts
powerbi/02_dax_measures.dax        ~35 DAX measures (time intelligence, ranks, RFM)
powerbi/03_dashboard_build_guide.md model, relationships, page-by-page visuals
outputs/                           summary CSVs, charts (PNG), data_quality_log.csv
```

## How to run
1. Put `Online_Retail.csv` in `data/raw/`, then `pip install -r requirements.txt`.
2. `python python/01_clean_and_eda.py`
3. In PostgreSQL create the DB: `CREATE DATABASE retail_db;`, set your password in `python/02_load_to_postgres.py`,
   then `python python/02_load_to_postgres.py`. Open `sql/03_analysis_queries.sql` in pgAdmin/DBeaver and run query by query.
4. `python excel/build_excel_workbook.py`, then follow `excel/EXCEL_GUIDE.md`.
5. Build the dashboard with `powerbi/` files.

## Data cleaning log (rows)
| Step | Removed | Remaining |
|---|---|---|
| Raw file | – | 541,909 |
| Exact duplicates | 5,268 | 536,641 |
| Non-product codes (POST, DOT, M, BANK CHARGES, gift vouchers…) | 2,944 | 533,697 |
| UnitPrice ≤ 0 | 2,492 | 531,205 |
Other decisions: dates parsed as dd-mm-yyyy; cancelled invoices (prefix `C`) kept and flagged as returns;
135,080 rows without CustomerID kept for revenue analysis but excluded from RFM/cohorts; one canonical description per StockCode.

## Key findings (verified identically in Python, SQL and Excel)
* **Gross revenue £10.25M, returns £0.48M (4.6%), net £9.77M**; 19,773 orders; AOV £518; 4,334 identified customers.
* **Seasonality:** Sep–Nov 2011 is the peak (Nov = £1.43M, the best month); Dec-2011 is partial (data ends 9 Dec).
* **Geography:** UK = 85% of revenue; Netherlands, EIRE, Germany, France lead exports.
* **Product concentration:** ~21% of products generate 80% of revenue (Pareto).
* **Customers:** "Champions" are ~26% of identified customers but ~66% of revenue; ~15% of revenue is guest checkouts.
* **Retention:** average monthly cohort keeps ~18% of customers in months 1–3.
* **Timing:** Thursday is the strongest weekday; peak hours are 10:00–15:00; no Saturday trading in the data.
* **Returns caveat:** the two largest "returns" are same-day order/cancel pairs (80,995 and 74,215 units) – they inflate
  both gross and returns equally; net revenue is unaffected. They are flagged `IsOutlierQty`.

## Recommendations (for your report's conclusion)
1. Stock up and run campaigns from September; November is the demand peak.
2. Protect the Champions segment (loyalty rewards) and win back "At Risk / Can't Lose Them" with targeted offers.
3. Grow exports beyond the UK (only 15% of revenue) starting with the Netherlands, EIRE, Germany, France.
4. Investigate high-return products and the order/cancel reversals in the order-entry process.
5. Capture CustomerID at checkout – 15% of revenue cannot be attributed to a customer.

## Mapping to your internship report
Python cleaning/EDA → §3.4 Weeks 2; SQL joins/window functions → Week 3; Excel pivots/VLOOKUP → Phase 5;
Power BI star schema + DAX (MTD, ranks) → §3.2, §4.1; testing = cross-tool reconciliation table in `excel/EXCEL_GUIDE.md`.
