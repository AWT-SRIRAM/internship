# Power BI – Dashboard Build Guide

## 1. Connect
1. **Home → Get Data → PostgreSQL database** → server `localhost:5432`, database `retail_db` (Import mode).
   Or paste the queries from `01_power_query_postgres.m` (Home → Get Data → Blank Query → Advanced Editor).
2. Load: `fact_sales`, `dim_date`, `dim_product`, `dim_country`, `dim_customer` (schema `retail`).

## 2. Model (Star schema – Model view)
| From (many) | To (one) | Cardinality | Direction |
|---|---|---|---|
| fact_sales[date_key] | dim_date[date_key] | * : 1 | Single |
| fact_sales[product_key] | dim_product[product_key] | * : 1 | Single |
| fact_sales[customer_key] | dim_customer[customer_key] | * : 1 | Single |
| fact_sales[country_key] | dim_country[country_key] | * : 1 | Single |

* Select `dim_date` → **Table tools → Mark as date table** → `full_date`.
* Sort `dim_date[month_name]` by `dim_date[month]`; sort `day_name` by `day_of_week`.
* Hide the key columns and `fact_sales[revenue]` (people should use the measures).
* Create the `_Measures` table and paste every measure from `02_dax_measures.dax`.

## 3. Report pages

### Page 1 – Executive Overview
| Visual | Fields |
|---|---|
| 5 KPI cards | Gross Sales, Net Revenue, Orders, Avg Order Value, Return Rate % |
| Line + clustered column | Axis `dim_date[year_month]`; columns = Net Revenue; line = Net Revenue 3M Rolling Avg |
| Filled map | Location `country_name`, size = Gross Sales |
| Bar chart | Top 10 products by Gross Sales (Top N filter on `dim_product[description]`) |
| Slicers | `year_month` (or date range), `region`, `country_name` |

### Page 2 – Product & Country Analysis
* Matrix: `region → country_name` × Gross Sales, Orders, AOV, Revenue Share % (conditional-format data bars).
* Pareto: columns = Gross Sales by product (Top 50), line = Cumulative Product Share %.
* Treemap: `region` / `country_name` by Gross Sales.
* Column chart: weekday (`day_name`) vs Gross Sales.

### Page 3 – Customer Insights (RFM)
* Donut: customers by `dim_customer[segment]`.
* Clustered bar: Gross Sales by `segment` (sort with Segment Order).
* Cards: Champions Customers, Champions Revenue %, At-Risk Customers, Repeat Customer Rate %.
* Table: top 20 customers (customer_name, segment, Gross Sales, Orders).
* (Optional) bring in `retail.rfm_customers` and add a scatter: x = frequency, y = monetary, colour = segment.

### Page 4 – Returns & Data Quality
* Cards: Returns Value, Return Rate %.
* Column chart: Returns Value by `year_month`.
* Bar chart: Top 10 products by Returns Value.
* Card: Outlier Lines + text box documenting the cleaning steps (see `outputs/data_quality_log.csv`).

## 4. Formatting checklist
* One theme (View → Themes), consistent fonts, titles on every visual.
* Conditional formatting: Net Revenue MoM % font colour → Field value → `MoM Colour`.
* Tooltips: add a report-page tooltip with Gross Sales, Orders, AOV.
* Bookmarks + buttons for page navigation; Sync slicers across pages 1–3.
* Insert text box with the data source note: *UCI Online Retail dataset, 01 Dec 2010 – 09 Dec 2011, GBP*.

## 5. Optional – Row-Level Security (matches the governance topics in your report)
Modeling → Manage roles → role `UK_Team`, table filter on `dim_country`:
`[country_name] = "United Kingdom"`. Role `Export_Team`: `[country_name] <> "United Kingdom"`.
Test with View as.

## 6. Publish / export
Save as `Online_Retail_Dashboard.pbix`, take page screenshots for the report, and (if you have a work/school account) Publish → Power BI Service.
