// ============================================================================
// Online Retail Analytics Project | Step 4 of 4 | POWER BI  -  Power Query (M)
// Home > Get Data > Blank Query > Advanced Editor : create one query per block
// below and name each query exactly as in the comment (fact_sales, dim_date, ...).
// Server/database: change "localhost:5432" / "retail_db" if yours differ.
// ============================================================================

// ---- Query name: fact_sales -------------------------------------------------
let
    Source   = PostgreSQL.Database("localhost:5432", "retail_db"),
    Raw      = Source{[Schema = "retail", Item = "fact_sales"]}[Data],
    Typed    = Table.TransformColumnTypes(Raw, {
                 {"sales_key", Int64.Type}, {"date_key", Int64.Type}, {"product_key", Int64.Type},
                 {"customer_key", Int64.Type}, {"country_key", Int64.Type},
                 {"quantity", Int64.Type}, {"unit_price", Currency.Type}, {"revenue", Currency.Type},
                 {"is_return", type logical}, {"is_outlier_qty", type logical},
                 {"invoice_ts", type datetime}, {"invoice_no", type text}}),
    // keep only what the report needs -> smaller, faster model
    Slim     = Table.SelectColumns(Typed, {"sales_key", "invoice_no", "date_key", "invoice_ts",
                 "product_key", "customer_key", "country_key", "quantity", "unit_price",
                 "revenue", "is_return", "is_outlier_qty"})
in
    Slim

// ---- Query name: dim_date -----------------------------------------------------
let
    Source = PostgreSQL.Database("localhost:5432", "retail_db"),
    Raw    = Source{[Schema = "retail", Item = "dim_date"]}[Data],
    Typed  = Table.TransformColumnTypes(Raw, {{"date_key", Int64.Type}, {"full_date", type date},
                 {"year", Int64.Type}, {"quarter", Int64.Type}, {"month", Int64.Type},
                 {"day_of_week", Int64.Type}, {"is_weekend", type logical}})
in
    Typed

// ---- Query name: dim_product ----------------------------------------------------
let
    Source = PostgreSQL.Database("localhost:5432", "retail_db"),
    Raw    = Source{[Schema = "retail", Item = "dim_product"]}[Data],
    Result = Table.TransformColumns(Raw, {{"description", Text.Proper, type text}})
in
    Result

// ---- Query name: dim_country ----------------------------------------------------
let
    Source = PostgreSQL.Database("localhost:5432", "retail_db"),
    Raw    = Source{[Schema = "retail", Item = "dim_country"]}[Data]
in
    Raw

// ---- Query name: dim_customer ---------------------------------------------------
let
    Source = PostgreSQL.Database("localhost:5432", "retail_db"),
    Raw    = Source{[Schema = "retail", Item = "dim_customer"]}[Data]
in
    Raw

// ============================================================================
// ALTERNATIVE (no PostgreSQL on the machine): load the clean CSV directly.
// Query name: sales_csv  -> then use it instead of fact_sales (single flat table)
// ============================================================================
let
    Source   = Csv.Document(File.Contents("C:\path\to\online_retail_project\data\clean\online_retail_clean.csv"),
                 [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    Typed    = Table.TransformColumnTypes(Promoted, {
                 {"InvoiceNo", type text}, {"StockCode", type text}, {"Description", type text},
                 {"Quantity", Int64.Type}, {"InvoiceDate", type datetime}, {"UnitPrice", Currency.Type},
                 {"CustomerID", Int64.Type}, {"Country", type text}, {"Revenue", Currency.Type},
                 {"IsReturn", type logical}, {"HasCustomer", type logical}, {"IsOutlierQty", type logical}}),
    AddMonth = Table.AddColumn(Typed, "YearMonth", each Date.ToText(DateTime.Date([InvoiceDate]), "yyyy-MM"), type text)
in
    AddMonth
