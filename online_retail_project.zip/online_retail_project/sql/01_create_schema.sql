-- ============================================================================
-- Online Retail Analytics Project | Step 2 of 4 | POSTGRESQL
-- 01_create_schema.sql : schema, staging table, star-schema tables
-- Run:  psql -U postgres -d retail_db -f sql/01_create_schema.sql
-- (create the database first:  CREATE DATABASE retail_db;)
-- ============================================================================

DROP SCHEMA IF EXISTS retail CASCADE;
CREATE SCHEMA retail;
SET search_path TO retail;

-- ---------------------------------------------------------------------------
-- STAGING: 1-to-1 copy of data/clean/online_retail_clean.csv
-- ---------------------------------------------------------------------------
CREATE TABLE stg_sales (
    invoice_no      VARCHAR(20),
    stock_code      VARCHAR(30),
    description     TEXT,
    quantity        INTEGER,
    invoice_date    TIMESTAMP,
    unit_price      NUMERIC(12,2),
    customer_id     INTEGER,            -- NULL = guest checkout
    country         VARCHAR(60),
    revenue         NUMERIC(14,2),      -- quantity * unit_price (negative for returns)
    is_return       BOOLEAN,
    has_customer    BOOLEAN,
    is_outlier_qty  BOOLEAN
);

-- Customer segments produced by Python (data/clean/rfm_customers.csv)
CREATE TABLE rfm_customers (
    customer_id  INTEGER PRIMARY KEY,
    recency      INTEGER,
    frequency    INTEGER,
    monetary     NUMERIC(14,2),
    country      VARCHAR(60),
    r_score      SMALLINT,
    f_score      SMALLINT,
    m_score      SMALLINT,
    rfm_score    VARCHAR(3),
    segment      VARCHAR(30)
);

-- ---------------------------------------------------------------------------
-- STAR SCHEMA
-- ---------------------------------------------------------------------------
CREATE TABLE dim_date (
    date_key      INTEGER PRIMARY KEY,      -- yyyymmdd
    full_date     DATE NOT NULL UNIQUE,
    year          SMALLINT,
    quarter       SMALLINT,
    month         SMALLINT,
    month_name    VARCHAR(10),
    year_month    CHAR(7),                  -- 2011-03
    week_of_year  SMALLINT,
    day_of_week   SMALLINT,                 -- 1 = Monday
    day_name      VARCHAR(10),
    is_weekend    BOOLEAN
);

CREATE TABLE dim_product (
    product_key   SERIAL PRIMARY KEY,
    stock_code    VARCHAR(30) UNIQUE NOT NULL,
    description   TEXT
);

CREATE TABLE dim_country (
    country_key   SERIAL PRIMARY KEY,
    country_name  VARCHAR(60) UNIQUE NOT NULL,
    region        VARCHAR(30)
);

CREATE TABLE dim_customer (
    customer_key  INTEGER PRIMARY KEY,      -- = CustomerID ; 0 = guest / unknown
    customer_name VARCHAR(30),
    segment       VARCHAR(30),              -- from RFM
    rfm_score     VARCHAR(3)
);

CREATE TABLE fact_sales (
    sales_key       BIGSERIAL PRIMARY KEY,
    invoice_no      VARCHAR(20) NOT NULL,
    date_key        INTEGER  NOT NULL REFERENCES dim_date(date_key),
    invoice_ts      TIMESTAMP NOT NULL,
    product_key     INTEGER  NOT NULL REFERENCES dim_product(product_key),
    customer_key    INTEGER  NOT NULL REFERENCES dim_customer(customer_key),
    country_key     INTEGER  NOT NULL REFERENCES dim_country(country_key),
    quantity        INTEGER  NOT NULL,
    unit_price      NUMERIC(12,2) NOT NULL,
    revenue         NUMERIC(14,2) NOT NULL,
    is_return       BOOLEAN  NOT NULL,
    is_outlier_qty  BOOLEAN  NOT NULL
);
