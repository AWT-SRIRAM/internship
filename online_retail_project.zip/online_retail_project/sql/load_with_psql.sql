-- Alternative to python/02_load_to_postgres.py : load the CSVs with psql's \copy
-- Run from the project root:
--   psql -U postgres -d retail_db -f sql/01_create_schema.sql
--   psql -U postgres -d retail_db -f sql/load_with_psql.sql
--   psql -U postgres -d retail_db -f sql/02_build_star_schema.sql
--   psql -U postgres -d retail_db -f sql/04_views_for_powerbi.sql
SET search_path TO retail;

\copy stg_sales (invoice_no, stock_code, description, quantity, invoice_date, unit_price, customer_id, country, revenue, is_return, has_customer, is_outlier_qty) FROM 'data/clean/online_retail_clean.csv' WITH (FORMAT csv, HEADER true, NULL '')

\copy rfm_customers (customer_id, recency, frequency, monetary, country, r_score, f_score, m_score, rfm_score, segment) FROM 'data/clean/rfm_customers.csv' WITH (FORMAT csv, HEADER true, NULL '')
