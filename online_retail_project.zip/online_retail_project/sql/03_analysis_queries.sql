-- ============================================================================
-- 03_analysis_queries.sql : business analysis using joins, CTEs, window functions
-- ============================================================================
SET search_path TO retail;

-- Q1. Headline KPIs ---------------------------------------------------------
SELECT  ROUND(SUM(revenue) FILTER (WHERE NOT is_return), 2)                      AS gross_revenue,
        ROUND(-SUM(revenue) FILTER (WHERE is_return), 2)                         AS returns_value,
        ROUND(SUM(revenue), 2)                                                   AS net_revenue,
        ROUND(-100.0 * SUM(revenue) FILTER (WHERE is_return)
                      / SUM(revenue) FILTER (WHERE NOT is_return), 2)            AS return_rate_pct,
        COUNT(DISTINCT invoice_no) FILTER (WHERE NOT is_return)                  AS orders,
        COUNT(DISTINCT customer_key) FILTER (WHERE customer_key <> 0)           AS customers
FROM    fact_sales;

-- Q2. Monthly revenue with month-over-month growth (LAG) ----------------------
WITH monthly AS (
    SELECT d.year_month,
           SUM(f.revenue) AS net_revenue
    FROM   fact_sales f JOIN dim_date d USING (date_key)
    GROUP  BY d.year_month
)
SELECT year_month,
       ROUND(net_revenue, 2)                                                    AS net_revenue,
       ROUND(100.0 * (net_revenue - LAG(net_revenue) OVER (ORDER BY year_month))
             / NULLIF(LAG(net_revenue) OVER (ORDER BY year_month), 0), 1)       AS mom_growth_pct,
       ROUND(SUM(net_revenue) OVER (ORDER BY year_month), 2)                    AS running_total
FROM   monthly
ORDER  BY year_month;

-- Q3. Revenue by country with rank and share (RANK) ---------------------------
SELECT  RANK() OVER (ORDER BY SUM(f.revenue) DESC)                              AS rnk,
        c.country_name,
        ROUND(SUM(f.revenue), 2)                                                AS net_revenue,
        ROUND(100.0 * SUM(f.revenue) / SUM(SUM(f.revenue)) OVER (), 2)          AS share_pct,
        COUNT(DISTINCT f.customer_key) FILTER (WHERE f.customer_key <> 0)       AS customers
FROM    fact_sales f JOIN dim_country c USING (country_key)
GROUP   BY c.country_name
ORDER   BY rnk
LIMIT   15;

-- Q4. Top 3 products in every month (ROW_NUMBER in a CTE) ---------------------
WITH product_month AS (
    SELECT d.year_month, p.description, SUM(f.revenue) AS revenue,
           ROW_NUMBER() OVER (PARTITION BY d.year_month ORDER BY SUM(f.revenue) DESC) AS rn
    FROM   fact_sales f
    JOIN   dim_date d    USING (date_key)
    JOIN   dim_product p USING (product_key)
    WHERE  NOT f.is_return
    GROUP  BY d.year_month, p.description
)
SELECT year_month, rn AS position, description, ROUND(revenue, 2) AS revenue
FROM   product_month
WHERE  rn <= 3
ORDER  BY year_month, rn;

-- Q5. Pareto analysis: how many products make 80% of sales? ---------------------
WITH prod AS (
    SELECT p.description, SUM(f.revenue) AS revenue
    FROM   fact_sales f JOIN dim_product p USING (product_key)
    WHERE  NOT f.is_return GROUP BY p.description
), cum AS (
    SELECT description, revenue,
           SUM(revenue) OVER (ORDER BY revenue DESC) / SUM(revenue) OVER () AS cum_share
    FROM   prod
)
SELECT COUNT(*) AS products_for_80pct_revenue,
       (SELECT COUNT(*) FROM prod)               AS total_products
FROM   cum WHERE cum_share <= 0.80;

-- Q6. Sales pattern by weekday and hour -----------------------------------------
SELECT d.day_name, d.day_of_week,
       ROUND(SUM(f.revenue), 0) AS revenue,
       COUNT(DISTINCT f.invoice_no) AS orders
FROM   fact_sales f JOIN dim_date d USING (date_key)
WHERE  NOT f.is_return
GROUP  BY d.day_name, d.day_of_week
ORDER  BY d.day_of_week;

SELECT EXTRACT(HOUR FROM invoice_ts)::INT AS hour,
       ROUND(SUM(revenue), 0)             AS revenue
FROM   fact_sales WHERE NOT is_return
GROUP  BY 1 ORDER BY 1;

-- Q7. Average order value and basket size per country -----------------------------
WITH orders AS (
    SELECT invoice_no, country_key, SUM(revenue) AS order_value, SUM(quantity) AS items
    FROM   fact_sales WHERE NOT is_return
    GROUP  BY invoice_no, country_key
)
SELECT c.country_name,
       COUNT(*)                       AS orders,
       ROUND(AVG(order_value), 2)     AS avg_order_value,
       ROUND(AVG(items), 1)           AS avg_items_per_order
FROM   orders o JOIN dim_country c USING (country_key)
GROUP  BY c.country_name
HAVING COUNT(*) >= 50
ORDER  BY avg_order_value DESC
LIMIT  10;

-- Q8. Customer lifetime value & purchase gaps (LAG on invoice dates) ---------------
WITH inv AS (
    SELECT customer_key, invoice_no, MIN(invoice_ts) AS ts, SUM(revenue) AS value
    FROM   fact_sales
    WHERE  customer_key <> 0 AND NOT is_return
    GROUP  BY customer_key, invoice_no
), gaps AS (
    SELECT customer_key, value,
           ts::DATE - LAG(ts::DATE) OVER (PARTITION BY customer_key ORDER BY ts) AS days_since_prev
    FROM   inv
)
SELECT customer_key,
       COUNT(*)                         AS orders,
       ROUND(SUM(value), 2)             AS lifetime_value,
       ROUND(AVG(days_since_prev), 1)   AS avg_days_between_orders
FROM   gaps
GROUP  BY customer_key
ORDER  BY lifetime_value DESC
LIMIT  10;

-- Q9. RFM segmentation done in pure SQL with NTILE (cross-check for Python) -----------
WITH base AS (
    SELECT customer_key,
           (SELECT MAX(invoice_ts)::DATE + 1 FROM fact_sales) - MAX(invoice_ts)::DATE AS recency,
           COUNT(DISTINCT invoice_no) AS frequency,
           SUM(revenue)               AS monetary
    FROM   fact_sales
    WHERE  customer_key <> 0 AND NOT is_return
    GROUP  BY customer_key
), scored AS (
    SELECT *,
           NTILE(5) OVER (ORDER BY recency DESC)   AS r,
           NTILE(5) OVER (ORDER BY frequency)      AS f,
           NTILE(5) OVER (ORDER BY monetary)       AS m
    FROM   base
)
SELECT CASE WHEN r >= 4 AND f >= 4 THEN 'Champions'
            WHEN r >= 3 AND f >= 3 THEN 'Loyal / Potential'
            WHEN r <= 2 AND f >= 3 THEN 'At Risk'
            WHEN r <= 2 AND f <= 2 THEN 'Lost'
            ELSE 'Others' END                         AS segment,
       COUNT(*)                                       AS customers,
       ROUND(SUM(monetary), 0)                        AS revenue
FROM   scored
GROUP  BY 1
ORDER  BY revenue DESC;

-- Q10. Monthly cohort retention ----------------------------------------------------------
WITH first_buy AS (
    SELECT customer_key, DATE_TRUNC('month', MIN(invoice_ts))::DATE AS cohort_month
    FROM   fact_sales WHERE customer_key <> 0 AND NOT is_return GROUP BY customer_key
), activity AS (
    SELECT DISTINCT f.customer_key, DATE_TRUNC('month', f.invoice_ts)::DATE AS active_month
    FROM   fact_sales f WHERE f.customer_key <> 0 AND NOT f.is_return
), cohort AS (
    SELECT fb.cohort_month,
           (EXTRACT(YEAR FROM a.active_month) - EXTRACT(YEAR FROM fb.cohort_month)) * 12
         + (EXTRACT(MONTH FROM a.active_month) - EXTRACT(MONTH FROM fb.cohort_month)) AS month_no,
           COUNT(DISTINCT a.customer_key) AS customers
    FROM   first_buy fb JOIN activity a USING (customer_key)
    GROUP  BY 1, 2
)
SELECT cohort_month, month_no::INT,
       customers,
       ROUND(100.0 * customers / FIRST_VALUE(customers) OVER (PARTITION BY cohort_month ORDER BY month_no), 1)
           AS retention_pct
FROM   cohort
ORDER  BY cohort_month, month_no;

-- Q11. Most returned products (return rate = returned qty / sold qty) ------------------------
SELECT p.description,
       SUM(f.quantity) FILTER (WHERE NOT f.is_return)      AS units_sold,
       -SUM(f.quantity) FILTER (WHERE f.is_return)         AS units_returned,
       ROUND(-100.0 * SUM(f.quantity) FILTER (WHERE f.is_return)
             / NULLIF(SUM(f.quantity) FILTER (WHERE NOT f.is_return), 0), 1) AS return_rate_pct
FROM   fact_sales f JOIN dim_product p USING (product_key)
GROUP  BY p.description
HAVING SUM(f.quantity) FILTER (WHERE NOT f.is_return) >= 500
ORDER  BY return_rate_pct DESC NULLS LAST
LIMIT  10;

-- Q12. Products frequently bought together (market-basket pairs) -------------------------------
-- Restricted to the 150 best-selling products and de-duplicated per invoice so the
-- self-join stays fast on ~500k rows.
WITH top_products AS (
    SELECT product_key FROM fact_sales
    WHERE  NOT is_return GROUP BY product_key
    ORDER  BY SUM(revenue) DESC LIMIT 150
), basket AS (
    SELECT DISTINCT f.invoice_no, f.product_key
    FROM   fact_sales f JOIN top_products USING (product_key)
    WHERE  NOT f.is_return
)
SELECT p1.description AS product_a,
       p2.description AS product_b,
       COUNT(*)       AS times_together
FROM   basket a
JOIN   basket b       ON a.invoice_no = b.invoice_no AND a.product_key < b.product_key
JOIN   dim_product p1 ON p1.product_key = a.product_key
JOIN   dim_product p2 ON p2.product_key = b.product_key
GROUP  BY 1, 2
ORDER  BY times_together DESC
LIMIT  10;
