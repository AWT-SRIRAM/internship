-- ============================================================================
-- 02_build_star_schema.sql : populate dimensions + fact from staging
-- Run AFTER staging (stg_sales, rfm_customers) has been loaded
--   (python/02_load_to_postgres.py does this, or use sql/load_with_psql.sql)
-- ============================================================================
SET search_path TO retail;

-- ---- dim_date : one row per calendar day in the data range ----------------
INSERT INTO dim_date
SELECT  TO_CHAR(d, 'YYYYMMDD')::INT,
        d::DATE,
        EXTRACT(YEAR    FROM d),
        EXTRACT(QUARTER FROM d),
        EXTRACT(MONTH   FROM d),
        TO_CHAR(d, 'Mon'),
        TO_CHAR(d, 'YYYY-MM'),
        EXTRACT(WEEK    FROM d),
        EXTRACT(ISODOW  FROM d),
        TRIM(TO_CHAR(d, 'Day')),
        EXTRACT(ISODOW  FROM d) IN (6, 7)
FROM generate_series(
        (SELECT MIN(invoice_date)::DATE FROM stg_sales),
        (SELECT MAX(invoice_date)::DATE FROM stg_sales),
        INTERVAL '1 day') AS d;

-- ---- dim_product : one row per stock code ----------------------------------
INSERT INTO dim_product (stock_code, description)
SELECT stock_code, MAX(description)          -- python already made description unique per code
FROM   stg_sales
GROUP  BY stock_code;

-- ---- dim_country with a simple region grouping -----------------------------
INSERT INTO dim_country (country_name, region)
SELECT DISTINCT country,
       CASE
         WHEN country = 'United Kingdom' THEN 'United Kingdom'
         WHEN country IN ('Austria','Belgium','Channel Islands','Cyprus','Czech Republic',
                          'Denmark','EIRE','European Community','Finland','France','Germany',
                          'Greece','Iceland','Italy','Lithuania','Malta','Netherlands',
                          'Norway','Poland','Portugal','Spain','Sweden','Switzerland')
                                          THEN 'Europe (non-UK)'
         WHEN country = 'Unspecified'     THEN 'Unspecified'
         ELSE 'Rest of World'
       END
FROM   stg_sales;

-- ---- dim_customer : guest row (0) + every identified customer ---------------
INSERT INTO dim_customer VALUES (0, 'Guest / Unknown', 'Guest', NULL);

INSERT INTO dim_customer (customer_key, customer_name, segment, rfm_score)
SELECT  c.customer_id,
        'Customer ' || c.customer_id,
        COALESCE(r.segment, 'Returns-only'),    -- customers who only ever returned goods
        r.rfm_score
FROM   (SELECT DISTINCT customer_id FROM stg_sales WHERE customer_id IS NOT NULL) c
LEFT   JOIN rfm_customers r USING (customer_id);

-- ---- fact_sales ---------------------------------------------------------------
INSERT INTO fact_sales (invoice_no, date_key, invoice_ts, product_key, customer_key,
                        country_key, quantity, unit_price, revenue, is_return, is_outlier_qty)
SELECT  s.invoice_no,
        TO_CHAR(s.invoice_date, 'YYYYMMDD')::INT,
        s.invoice_date,
        p.product_key,
        COALESCE(s.customer_id, 0),
        c.country_key,
        s.quantity, s.unit_price, s.revenue, s.is_return, s.is_outlier_qty
FROM    stg_sales s
JOIN    dim_product p ON p.stock_code   = s.stock_code
JOIN    dim_country c ON c.country_name = s.country;

-- ---- indexes for the join / filter columns ------------------------------------
CREATE INDEX idx_fact_date     ON fact_sales(date_key);
CREATE INDEX idx_fact_product  ON fact_sales(product_key);
CREATE INDEX idx_fact_customer ON fact_sales(customer_key);
CREATE INDEX idx_fact_country  ON fact_sales(country_key);
CREATE INDEX idx_fact_invoice  ON fact_sales(invoice_no);

ANALYZE;

-- ---- sanity checks: staging and fact must reconcile -----------------------------
SELECT 'stg_sales' AS tbl, COUNT(*) AS row_count, SUM(revenue) AS total_revenue FROM stg_sales
UNION ALL
SELECT 'fact_sales',        COUNT(*),               SUM(revenue)                FROM fact_sales;
