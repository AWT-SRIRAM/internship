-- ============================================================================
-- 04_views_for_powerbi.sql : reporting views (Power BI can import these directly)
-- ============================================================================
SET search_path TO retail;

CREATE OR REPLACE VIEW vw_sales_detail AS
SELECT  f.sales_key, f.invoice_no, f.invoice_ts, d.full_date, d.year, d.quarter, d.month,
        d.month_name, d.year_month, d.day_name, d.is_weekend,
        p.stock_code, p.description AS product, c.country_name AS country, c.region,
        cu.customer_key, cu.segment AS rfm_segment,
        f.quantity, f.unit_price, f.revenue, f.is_return
FROM    fact_sales f
JOIN    dim_date d      USING (date_key)
JOIN    dim_product p   USING (product_key)
JOIN    dim_country c   USING (country_key)
JOIN    dim_customer cu USING (customer_key);

CREATE OR REPLACE VIEW vw_monthly_kpi AS
SELECT  d.year_month,
        SUM(f.revenue) FILTER (WHERE NOT f.is_return)    AS gross_revenue,
        -SUM(f.revenue) FILTER (WHERE f.is_return)       AS returns_value,
        SUM(f.revenue)                                   AS net_revenue,
        COUNT(DISTINCT f.invoice_no) FILTER (WHERE NOT f.is_return) AS orders,
        COUNT(DISTINCT NULLIF(f.customer_key, 0))        AS customers
FROM    fact_sales f JOIN dim_date d USING (date_key)
GROUP   BY d.year_month;
