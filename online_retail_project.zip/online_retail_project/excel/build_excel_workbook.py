"""
Online Retail Analytics Project  |  Step 3 of 4  |  EXCEL
==========================================================
Builds excel/Online_Retail_Analysis.xlsx from the Python outputs.
All derived numbers (Net revenue, MoM %, shares, ranks, KPIs, lookups) are LIVE
Excel formulas, so you can show SUMIFS / COUNTIFS / INDEX-MATCH in your report.

Run (after python/01_clean_and_eda.py):
    python excel/build_excel_workbook.py
Then, if you have Excel: open the file and follow excel/EXCEL_GUIDE.md to add
Pivot Tables and slicers on the Data_Sample sheet (or on the full CSV via Power Query).
"""

from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
CLEAN = ROOT / "data" / "clean" / "online_retail_clean.csv"
TARGET = ROOT / "excel" / "Online_Retail_Analysis.xlsx"

FONT = "Arial"
HEAD_FILL = PatternFill("solid", start_color="1F3864")
INPUT_BLUE = Font(name=FONT, color="0000FF", size=10)       # hard-coded values from Python
CALC_BLACK = Font(name=FONT, color="000000", size=10)       # formulas
LINK_GREEN = Font(name=FONT, color="008000", size=10)       # cross-sheet links
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
GBP = '£#,##0;(£#,##0);-'
GBP2 = '£#,##0.00;(£#,##0.00);-'
INT = '#,##0;(#,##0);-'
PCT = '0.0%;(0.0%);-'


def header(ws, row, labels, widths=None):
    for i, lab in enumerate(labels, 1):
        c = ws.cell(row=row, column=i, value=lab)
        c.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
        c.fill = HEAD_FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = BORDER
        if widths:
            ws.column_dimensions[get_column_letter(i)].width = widths[i - 1]
    ws.row_dimensions[row].height = 30


def title(ws, text, sub=None):
    ws["A1"] = text
    ws["A1"].font = Font(name=FONT, bold=True, size=14, color="1F3864")
    if sub:
        ws["A2"] = sub
        ws["A2"].font = Font(name=FONT, italic=True, size=9, color="595959")


def style_cell(c, font, fmt=None):
    c.font = font
    c.border = BORDER
    if fmt:
        c.number_format = fmt


wb = Workbook()

# ----------------------------------------------------------------------------
# README
# ----------------------------------------------------------------------------
ws = wb.active
ws.title = "README"
title(ws, "Online Retail Analysis - Excel Workbook",
      "Source: UCI Online Retail dataset (Dec 2010 - Dec 2011), cleaned with Python (see python/01_clean_and_eda.py)")
rows = [
    ("Sheet", "Purpose"),
    ("KPI_Summary", "Headline KPIs - every figure is a formula pointing at the other sheets"),
    ("Monthly", "Monthly gross / returns / net revenue, MoM growth, running total, AOV (formulas)"),
    ("Country", "Revenue by country with share %, rank and cumulative share (formulas)"),
    ("Top_Products", "Top 50 products with average selling price and revenue share (formulas)"),
    ("RFM_Segments", "Customer segments from the Python RFM model with revenue share (formulas)"),
    ("Returns", "Top returned products"),
    ("Data_Sample", "5,000-row random sample of the clean data (Revenue and Month are formulas) - use it for Pivot Tables"),
    ("Formula_Demo", "SUMIFS / COUNTIFS / AVERAGEIFS / INDEX-MATCH / VLOOKUP examples on Data_Sample"),
    ("", ""),
    ("Colour code", "Blue = value imported from Python | Black = Excel formula | Green = link to another sheet"),
    ("Assumptions", "Currency is GBP (the dataset's native currency). Returns are invoices starting with 'C'. "
                    "Non-product lines (postage, bank charges, manual entries) and zero-price lines were removed in Python. "
                    "Gross/Net revenue include guest checkouts (no CustomerID)."),
]
for i, (a, b) in enumerate(rows, start=4):
    ws.cell(row=i, column=1, value=a).font = Font(name=FONT, bold=(i == 4 or a in ("Colour code", "Assumptions")), size=10)
    ws.cell(row=i, column=2, value=b).font = Font(name=FONT, size=10)
    ws.cell(row=i, column=2).alignment = Alignment(wrap_text=True, vertical="top")
ws.column_dimensions["A"].width = 18
ws.column_dimensions["B"].width = 110

# ----------------------------------------------------------------------------
# MONTHLY
# ----------------------------------------------------------------------------
m = pd.read_csv(OUT / "monthly_summary.csv")
ws = wb.create_sheet("Monthly")
title(ws, "Monthly Performance", "Blue = from Python; black = formulas")
header(ws, 4, ["Month", "Gross Revenue", "Returns", "Net Revenue", "MoM Growth %",
               "Running Total", "Orders", "Avg Order Value", "Customers"],
       [12, 16, 14, 16, 14, 16, 10, 16, 12])
r0 = 5
for i, row in m.iterrows():
    r = r0 + i
    ws.cell(r, 1, row["YearMonth"]); style_cell(ws.cell(r, 1), INPUT_BLUE)
    ws.cell(r, 2, row["GrossRevenue"]); style_cell(ws.cell(r, 2), INPUT_BLUE, GBP)
    ws.cell(r, 3, row["Returns"]); style_cell(ws.cell(r, 3), INPUT_BLUE, GBP)
    ws.cell(r, 4, f"=B{r}-C{r}"); style_cell(ws.cell(r, 4), CALC_BLACK, GBP)
    ws.cell(r, 5, "" if i == 0 else f"=IF(D{r-1}=0,0,D{r}/D{r-1}-1)")
    style_cell(ws.cell(r, 5), CALC_BLACK, PCT)
    ws.cell(r, 6, f"=SUM($D${r0}:D{r})"); style_cell(ws.cell(r, 6), CALC_BLACK, GBP)
    ws.cell(r, 7, int(row["Orders"])); style_cell(ws.cell(r, 7), INPUT_BLUE, INT)
    ws.cell(r, 8, f"=IF(G{r}=0,0,B{r}/G{r})"); style_cell(ws.cell(r, 8), CALC_BLACK, GBP2)
    ws.cell(r, 9, int(row["Customers"])); style_cell(ws.cell(r, 9), INPUT_BLUE, INT)
r1 = r0 + len(m) - 1
rt = r1 + 1
ws.cell(rt, 1, "TOTAL").font = Font(name=FONT, bold=True, size=10)
for col, fmt in ((2, GBP), (3, GBP), (4, GBP), (7, INT)):
    L = get_column_letter(col)
    ws.cell(rt, col, f"=SUM({L}{r0}:{L}{r1})")
    style_cell(ws.cell(rt, col), Font(name=FONT, bold=True, size=10), fmt)
ws.cell(rt, 8, f"=B{rt}/G{rt}"); style_cell(ws.cell(rt, 8), Font(name=FONT, bold=True, size=10), GBP2)
ws.cell(rt + 2, 1, "Note: 'Customers' = distinct identified customers active in the month (guest checkouts excluded). "
                   "Dec-2011 is a partial month (data ends 9 Dec).").font = Font(name=FONT, italic=True, size=9)
ws.freeze_panes = "B5"

ch = BarChart(); ch.type = "col"; ch.title = "Monthly Net Revenue (GBP)"; ch.height = 8; ch.width = 20
ch.add_data(Reference(ws, min_col=4, min_row=4, max_row=r1), titles_from_data=True)
ch.set_categories(Reference(ws, min_col=1, min_row=r0, max_row=r1)); ch.legend = None
ws.add_chart(ch, f"A{rt + 4}")
lc = LineChart(); lc.title = "Month-over-Month Growth %"; lc.height = 8; lc.width = 20
lc.add_data(Reference(ws, min_col=5, min_row=4, max_row=r1), titles_from_data=True)
lc.set_categories(Reference(ws, min_col=1, min_row=r0, max_row=r1)); lc.legend = None
ws.add_chart(lc, f"G{rt + 4}")
MONTHLY = dict(r0=r0, r1=r1, rt=rt)

# ----------------------------------------------------------------------------
# COUNTRY
# ----------------------------------------------------------------------------
co = pd.read_csv(OUT / "country_summary.csv")
ws = wb.create_sheet("Country")
title(ws, "Revenue by Country (gross sales)", "Sorted by revenue; share, rank and cumulative share are formulas")
header(ws, 4, ["Country", "Revenue", "Orders", "Customers", "Share %", "Rank", "Cumulative Share %"],
       [22, 16, 10, 12, 10, 8, 18])
c0 = 5
for i, row in co.iterrows():
    r = c0 + i
    ws.cell(r, 1, row["Country"]); style_cell(ws.cell(r, 1), INPUT_BLUE)
    ws.cell(r, 2, row["Revenue"]); style_cell(ws.cell(r, 2), INPUT_BLUE, GBP)
    ws.cell(r, 3, int(row["Orders"])); style_cell(ws.cell(r, 3), INPUT_BLUE, INT)
    ws.cell(r, 4, int(row["Customers"])); style_cell(ws.cell(r, 4), INPUT_BLUE, INT)
c1 = c0 + len(co) - 1
for i in range(len(co)):
    r = c0 + i
    ws.cell(r, 5, f"=B{r}/SUM($B${c0}:$B${c1})"); style_cell(ws.cell(r, 5), CALC_BLACK, PCT)
    ws.cell(r, 6, f"=RANK(B{r},$B${c0}:$B${c1})"); style_cell(ws.cell(r, 6), CALC_BLACK, "0")
    ws.cell(r, 7, f"=SUM($E${c0}:E{r})"); style_cell(ws.cell(r, 7), CALC_BLACK, PCT)
ws.cell(c1 + 1, 1, "TOTAL").font = Font(name=FONT, bold=True, size=10)
ws.cell(c1 + 1, 2, f"=SUM(B{c0}:B{c1})"); style_cell(ws.cell(c1 + 1, 2), Font(name=FONT, bold=True, size=10), GBP)
ws.freeze_panes = "B5"
bc = BarChart(); bc.type = "bar"; bc.title = "Top 10 Countries by Revenue"; bc.height = 10; bc.width = 18
bc.add_data(Reference(ws, min_col=2, min_row=4, max_row=c0 + 9), titles_from_data=True)
bc.set_categories(Reference(ws, min_col=1, min_row=c0, max_row=c0 + 9)); bc.legend = None
bc.y_axis.scaling.orientation = "minMax"; bc.x_axis.scaling.orientation = "maxMin"
ws.add_chart(bc, "I4")
COUNTRY = dict(r0=c0, r1=c1)

# ----------------------------------------------------------------------------
# TOP PRODUCTS
# ----------------------------------------------------------------------------
tp = pd.read_csv(OUT / "top_products.csv")
ws = wb.create_sheet("Top_Products")
title(ws, "Top 50 Products by Revenue", "Avg price and share are formulas; share is of total gross revenue on KPI_Summary")
header(ws, 4, ["Stock Code", "Description", "Revenue", "Units", "Orders", "Avg Selling Price", "Share of Gross Revenue"],
       [12, 42, 14, 10, 10, 16, 20])
p0 = 5
for i, row in tp.iterrows():
    r = p0 + i
    ws.cell(r, 1, str(row["StockCode"])); style_cell(ws.cell(r, 1), INPUT_BLUE)
    ws.cell(r, 2, row["Description"]); style_cell(ws.cell(r, 2), INPUT_BLUE)
    ws.cell(r, 3, row["Revenue"]); style_cell(ws.cell(r, 3), INPUT_BLUE, GBP)
    ws.cell(r, 4, int(row["Units"])); style_cell(ws.cell(r, 4), INPUT_BLUE, INT)
    ws.cell(r, 5, int(row["Orders"])); style_cell(ws.cell(r, 5), INPUT_BLUE, INT)
    ws.cell(r, 6, f"=IF(D{r}=0,0,C{r}/D{r})"); style_cell(ws.cell(r, 6), CALC_BLACK, GBP2)
    ws.cell(r, 7, f"=C{r}/Monthly!$B${MONTHLY['rt']}"); style_cell(ws.cell(r, 7), LINK_GREEN, PCT)
p1 = p0 + len(tp) - 1
ws.freeze_panes = "C5"
pc = BarChart(); pc.type = "bar"; pc.title = "Top 10 Products by Revenue"; pc.height = 10; pc.width = 20
pc.add_data(Reference(ws, min_col=3, min_row=4, max_row=p0 + 9), titles_from_data=True)
pc.set_categories(Reference(ws, min_col=2, min_row=p0, max_row=p0 + 9)); pc.legend = None
pc.x_axis.scaling.orientation = "maxMin"
ws.add_chart(pc, "I4")

# ----------------------------------------------------------------------------
# RFM SEGMENTS
# ----------------------------------------------------------------------------
rf = pd.read_csv(OUT / "rfm_segment_summary.csv")
ws = wb.create_sheet("RFM_Segments")
title(ws, "RFM Customer Segments", "Quintile scoring of Recency, Frequency, Monetary (Python). Shares are formulas.")
header(ws, 4, ["Segment", "Customers", "Avg Recency (days)", "Avg Frequency (orders)", "Avg Monetary",
               "Revenue", "% of Customers", "% of Revenue", "Revenue per Customer"],
       [22, 12, 16, 18, 14, 16, 14, 14, 18])
s0 = 5
for i, row in rf.iterrows():
    r = s0 + i
    ws.cell(r, 1, row["Segment"]); style_cell(ws.cell(r, 1), INPUT_BLUE)
    ws.cell(r, 2, int(row["Customers"])); style_cell(ws.cell(r, 2), INPUT_BLUE, INT)
    ws.cell(r, 3, row["AvgRecency"]); style_cell(ws.cell(r, 3), INPUT_BLUE, "0.0")
    ws.cell(r, 4, row["AvgFrequency"]); style_cell(ws.cell(r, 4), INPUT_BLUE, "0.0")
    ws.cell(r, 5, row["AvgMonetary"]); style_cell(ws.cell(r, 5), INPUT_BLUE, GBP)
    ws.cell(r, 6, row["Revenue"]); style_cell(ws.cell(r, 6), INPUT_BLUE, GBP)
s1 = s0 + len(rf) - 1
for i in range(len(rf)):
    r = s0 + i
    ws.cell(r, 7, f"=B{r}/SUM($B${s0}:$B${s1})"); style_cell(ws.cell(r, 7), CALC_BLACK, PCT)
    ws.cell(r, 8, f"=F{r}/SUM($F${s0}:$F${s1})"); style_cell(ws.cell(r, 8), CALC_BLACK, PCT)
    ws.cell(r, 9, f"=F{r}/B{r}"); style_cell(ws.cell(r, 9), CALC_BLACK, GBP)
ws.cell(s1 + 1, 1, "TOTAL").font = Font(name=FONT, bold=True, size=10)
for col, fmt in ((2, INT), (6, GBP)):
    L = get_column_letter(col)
    ws.cell(s1 + 1, col, f"=SUM({L}{s0}:{L}{s1})")
    style_cell(ws.cell(s1 + 1, col), Font(name=FONT, bold=True, size=10), fmt)
rc = BarChart(); rc.type = "col"; rc.title = "Revenue by RFM Segment"; rc.height = 9; rc.width = 18
rc.add_data(Reference(ws, min_col=6, min_row=4, max_row=s1), titles_from_data=True)
rc.set_categories(Reference(ws, min_col=1, min_row=s0, max_row=s1)); rc.legend = None
ws.add_chart(rc, f"A{s1 + 4}")
RFM = dict(r0=s0, r1=s1)

# ----------------------------------------------------------------------------
# RETURNS
# ----------------------------------------------------------------------------
rt_df = pd.read_csv(OUT / "top_returned_products.csv")
ws = wb.create_sheet("Returns")
title(ws, "Top Returned Products (by value)",
      "Two of the largest items are a same-day order/cancellation pair of 80,995 and 74,215 units - treat as data-entry reversals")
header(ws, 4, ["Product", "Return Value", "% of Total Returns"], [44, 16, 20])
for i, row in rt_df.iterrows():
    r = 5 + i
    ws.cell(r, 1, row["Description"]); style_cell(ws.cell(r, 1), INPUT_BLUE)
    ws.cell(r, 2, row["ReturnValue"]); style_cell(ws.cell(r, 2), INPUT_BLUE, GBP)
    ws.cell(r, 3, f"=B{r}/Monthly!$C${MONTHLY['rt']}"); style_cell(ws.cell(r, 3), LINK_GREEN, PCT)

# ----------------------------------------------------------------------------
# DATA SAMPLE (formulas for Revenue / Month)
# ----------------------------------------------------------------------------
full = pd.read_csv(CLEAN, parse_dates=["InvoiceDate"])
sample = (full[~full["IsReturn"] & full["HasCustomer"]]
          .sample(5000, random_state=42).sort_values("InvoiceDate").reset_index(drop=True))
ws = wb.create_sheet("Data_Sample")
title(ws, "Data Sample (5,000 random sales lines, identified customers)",
      "Revenue and Month are formulas. Insert > PivotTable on A4:I5004 for the pivot exercises.")
header(ws, 4, ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate", "UnitPrice",
               "CustomerID", "Country", "Revenue", "Month"],
       [12, 12, 38, 10, 18, 11, 12, 18, 12, 10])
d0 = 5
for i, row in sample.iterrows():
    r = d0 + i
    vals = [str(row["InvoiceNo"]), str(row["StockCode"]), row["Description"], int(row["Quantity"]),
            row["InvoiceDate"].to_pydatetime(), float(row["UnitPrice"]), int(row["CustomerID"]), row["Country"]]
    for j, v in enumerate(vals, 1):
        c = ws.cell(r, j, v); c.font = INPUT_BLUE
    ws.cell(r, 5).number_format = "dd-mmm-yyyy hh:mm"
    ws.cell(r, 6).number_format = '£#,##0.00'
    ws.cell(r, 9, f"=D{r}*F{r}"); ws.cell(r, 9).font = CALC_BLACK; ws.cell(r, 9).number_format = GBP2
    ws.cell(r, 10, f'=TEXT(E{r},"yyyy-mm")'); ws.cell(r, 10).font = CALC_BLACK
d1 = d0 + len(sample) - 1
ws.freeze_panes = "A5"
ws.auto_filter.ref = f"A4:J{d1}"
DATA = dict(d0=d0, d1=d1)

# ----------------------------------------------------------------------------
# FORMULA DEMO
# ----------------------------------------------------------------------------
ws = wb.create_sheet("Formula_Demo")
title(ws, "Excel Formula Demonstrations on Data_Sample",
      "Change the yellow input cells and watch the results update")
ws.column_dimensions["A"].width = 38
ws.column_dimensions["B"].width = 22
ws.column_dimensions["C"].width = 70
YELLOW = PatternFill("solid", start_color="FFFF00")
R = f"Data_Sample!$I${DATA['d0']}:$I${DATA['d1']}"
CTRY = f"Data_Sample!$H${DATA['d0']}:$H${DATA['d1']}"
MON = f"Data_Sample!$J${DATA['d0']}:$J${DATA['d1']}"
CUST = f"Data_Sample!$G${DATA['d0']}:$G${DATA['d1']}"
QTY = f"Data_Sample!$D${DATA['d0']}:$D${DATA['d1']}"
DESC = f"Data_Sample!$C${DATA['d0']}:$C${DATA['d1']}"
INV = f"Data_Sample!$A${DATA['d0']}:$A${DATA['d1']}"

ws["A4"] = "Input: Country"; ws["B4"] = "Germany"
ws["A5"] = "Input: Month (yyyy-mm)"; ws["B5"] = "2011-06"
ws["A6"] = "Input: CustomerID"; ws["B6"] = int(sample["CustomerID"].iloc[0])
for a in ("B4", "B5", "B6"):
    ws[a].fill = YELLOW; ws[a].font = INPUT_BLUE
for a in ("A4", "A5", "A6"):
    ws[a].font = Font(name=FONT, bold=True, size=10)

demo = [
    ("Total sample revenue", f"=SUM({R})", GBP, "SUM"),
    ("Revenue for chosen country", f"=SUMIFS({R},{CTRY},B4)", GBP, "SUMIFS - single condition"),
    ("Revenue: country AND month", f"=SUMIFS({R},{CTRY},B4,{MON},B5)", GBP, "SUMIFS - two conditions"),
    ("Order lines for chosen country", f"=COUNTIFS({CTRY},B4)", INT, "COUNTIFS"),
    ("Average line value (country)", f'=IFERROR(AVERAGEIFS({R},{CTRY},B4),0)', GBP2, "AVERAGEIFS + IFERROR"),
    ("Largest single line (all)", f"=MAX({R})", GBP2, "MAX"),
    ("Units bought by chosen customer", f"=SUMIFS({QTY},{CUST},B6)", INT, "SUMIFS on customer"),
    ("Spend of chosen customer", f"=SUMIFS({R},{CUST},B6)", GBP2, "SUMIFS on customer"),
    ("First product bought (INDEX/MATCH)", f"=INDEX({DESC},MATCH(B6,{CUST},0))", None, "INDEX + MATCH (replaces VLOOKUP, looks left)"),
    ("Customer of first invoice (VLOOKUP)",
     f"=VLOOKUP(Data_Sample!A{DATA['d0']},Data_Sample!$A${DATA['d0']}:$J${DATA['d1']},7,FALSE)", "0",
     "VLOOKUP works because InvoiceNo is the FIRST column of the lookup range (7 = CustomerID column)"),
    ("Share of sample from chosen country", "=IFERROR(B10/B9,0)", PCT, "Ratio of the two cells above"),
]
header(ws, 8, ["Metric", "Result", "Formula type / note"])
for i, (lab, f, fmt, note) in enumerate(demo, start=9):
    ws.cell(i, 1, lab).font = Font(name=FONT, size=10)
    ws.cell(i, 2, f); ws.cell(i, 2).font = LINK_GREEN
    if fmt:
        ws.cell(i, 2).number_format = fmt
    ws.cell(i, 3, note).font = Font(name=FONT, italic=True, size=9, color="595959")
    ws.cell(i, 3).alignment = Alignment(wrap_text=True, vertical="top")
# ----------------------------------------------------------------------------
# KPI SUMMARY (all formulas linking to other sheets)
# ----------------------------------------------------------------------------
ws = wb.create_sheet("KPI_Summary", 1)
title(ws, "Headline KPIs", "Every number links to the analysis sheets (green) or is calculated (black)")
header(ws, 4, ["KPI", "Value", "How it is calculated"], [34, 20, 70])
mr = MONTHLY
kp = [
    ("Gross Revenue", f"=Monthly!B{mr['rt']}", GBP, "Sum of all sales lines (excl. returns)"),
    ("Returns Value", f"=Monthly!C{mr['rt']}", GBP, "Value of cancelled invoices"),
    ("Net Revenue", "=B5-B6", GBP, "Gross - Returns"),
    ("Return Rate", "=B6/B5", PCT, "Returns / Gross"),
    ("Orders", f"=Monthly!G{mr['rt']}", INT, "Distinct sales invoices"),
    ("Average Order Value", "=B5/B9", GBP2, "Gross revenue / orders"),
    ("Best Month (Net Revenue)", f"=INDEX(Monthly!A{mr['r0']}:A{mr['r1']},MATCH(MAX(Monthly!D{mr['r0']}:D{mr['r1']}),Monthly!D{mr['r0']}:D{mr['r1']},0))", None, "INDEX/MATCH on Monthly sheet"),
    ("Best Month Net Revenue", f"=MAX(Monthly!D{mr['r0']}:D{mr['r1']})", GBP, "MAX of monthly net revenue"),
    ("Top Country", f"=Country!A{COUNTRY['r0']}", None, "Rank 1 on Country sheet"),
    ("Top Country Share", f"=Country!E{COUNTRY['r0']}", PCT, "Share of gross revenue"),
    ("Non-UK Share of Revenue", f"=1-B14", PCT, "Export dependence"),
    ("Top Product", "=Top_Products!B5", None, "Highest revenue product"),
    ("Champions: % of Revenue", f"=INDEX(RFM_Segments!H{RFM['r0']}:H{RFM['r1']},MATCH(\"Champions\",RFM_Segments!A{RFM['r0']}:A{RFM['r1']},0))", PCT, "RFM top segment"),
    ("Champions: % of Customers", f"=INDEX(RFM_Segments!G{RFM['r0']}:G{RFM['r1']},MATCH(\"Champions\",RFM_Segments!A{RFM['r0']}:A{RFM['r1']},0))", PCT, "Pareto-style concentration"),
]
for i, (lab, f, fmt, note) in enumerate(kp, start=5):
    ws.cell(i, 1, lab).font = Font(name=FONT, bold=True, size=10)
    ws.cell(i, 1).border = BORDER
    ws.cell(i, 2, f)
    style_cell(ws.cell(i, 2), LINK_GREEN if "!" in f else CALC_BLACK, fmt)
    ws.cell(i, 2).alignment = Alignment(horizontal="right")
    ws.cell(i, 3, note).font = Font(name=FONT, italic=True, size=9, color="595959")

wb.save(TARGET)
print("Saved", TARGET)
