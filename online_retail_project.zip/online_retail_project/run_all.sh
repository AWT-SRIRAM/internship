#!/usr/bin/env bash
# Run the pipeline end-to-end (Linux/macOS/Git-Bash). On Windows run the commands one by one.
set -e
python python/01_clean_and_eda.py          # 1. clean + EDA + RFM  -> data/clean, outputs/
python python/02_load_to_postgres.py       # 2. build PostgreSQL warehouse (edit DB password first)
python excel/build_excel_workbook.py       # 3. Excel workbook
echo "Now open powerbi/03_dashboard_build_guide.md for the Power BI step."
